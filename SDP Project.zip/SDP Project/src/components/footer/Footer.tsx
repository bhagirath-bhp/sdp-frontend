import "./footer.scss"

const Footer = () => {
  return (
    <div className="footer">
      <span>Dashboard</span>
      <span>Dashboard</span>
    </div>
  )
}

export default Footer